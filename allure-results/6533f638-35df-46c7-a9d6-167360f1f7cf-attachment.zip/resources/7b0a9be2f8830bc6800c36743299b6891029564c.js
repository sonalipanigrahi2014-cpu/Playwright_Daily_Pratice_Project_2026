function registerAccount() {
  const result = document.getElementById("message");

  let emailValue = document.registerForm.emailAddress.value;
  console.log("email " + emailValue);
  let passwordValue = document.registerForm.password.value;
  console.log("psw " + passwordValue);

  if (emailValue.length > 0 && passwordValue.length > 0) {
    console.log("triggered");
    result.style.display = "block";
    result.innerHTML = "The account has been successfully created!";

    localStorage.setItem(emailValue, passwordValue);
  }
}
